from django.apps import AppConfig


class AjaxAppConfig(AppConfig):
    name = 'ajax_app'
