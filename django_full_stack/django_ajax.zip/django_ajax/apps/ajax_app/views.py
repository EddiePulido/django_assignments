from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import *
import bcrypt

def index(request):
    context = {
        'posts':Post.objects.all()
    }

    return render(request,"ajax_app/index.html", context)

def post(request):
    post = Post.objects.create(post=request.POST['note'])

    return redirect('/')