from django.apps import AppConfig


class DashAppConfig(AppConfig):
    name = 'dash_app'
